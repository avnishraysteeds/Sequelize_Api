const mongoose = require("mongoose");
const Schema = mongoose.Schema;
 const con=mongoose.connect("mongodb://localhost:27017/todo")
 if(con){
     console.log("connected")
 }
 else{
     console("not connected")
 }
 const workSchema = new Schema({
    work: {
        type: String,
        required: true,
    },
    completed: {
        type: String,
        default: false,
    },
    // work:"string",
    // completed:"string"
});

module.exports = mongoose.model("Work", workSchema);

