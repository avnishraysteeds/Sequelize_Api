const cors =require("cors");
const Work = require("./models/task");
const express = require("express");
const app = express();
app.use(express.json());

app.use(cors());

app.post("/save", async (req, res) => {
    try {
        
        const work = await new Work(req.body).save();
        res.status(200).send(work);
    } catch (error) {
        res.send(error);
    }
});

app.get("/find", async (req, res) => {
    try {
        const tasks = await Work.find();
        res.send(tasks);
        
    } catch (error) {
        res.send(error);
    }
});

app.put("/update/:id", async (req, res) => {
    try {
        const task = await Work.findOneAndUpdate(
            { _id: req.params.id },
            req.body
        );
        res.send(task);
    } catch (error) {
        res.send(error);
    }
});

app.delete("/delete/:id", async (req, res) => {
    try {
        console.log(req.params)
        const task = await Work.findByIdAndDelete(req.params.id);
        res.send(task);
    } catch (error) {
        res.send(error);
    }
});

app.listen(5000, ()=>{
    console.log("server started on port 5000");
});

module.exports = app;